import test from 'node:test';
import assert from 'node:assert/strict';
import { version } from '../lib/version.js';

test('the version reads as semver', () => {
  assert.match(version, /^\d+\.\d+\.\d+$/);
});
