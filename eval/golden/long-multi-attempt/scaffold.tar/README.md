# Config

Five independent sections, each still a bare legacy string. The migration usually outlives one attempt bound.
