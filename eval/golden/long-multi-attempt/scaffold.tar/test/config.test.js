import test from 'node:test';
import assert from 'node:assert/strict';

const names = ['one', 'two', 'three', 'four', 'five'];

for (const name of names) {
  test(`config/${name} exports a typed section`, async () => {
    const { section } = await import(`../config/${name}.js`);
    assert.deepEqual(section, { kind: 'typed', name });
  });
}
