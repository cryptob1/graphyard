export const section = 'legacy-three';
