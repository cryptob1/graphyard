# Settings

A tiny settings page with an e2e case. Its current render embeds the raw token in a page attribute.
