import test from 'node:test';
import assert from 'node:assert/strict';
import { applyPreference } from '../web/app.js';

const element = { setAttribute(key, value) { this[key] = value; }, innerHTML: '' };

test('a stored preference renders as the toggle state', () => {
  applyPreference(element, { telemetry: true });
  assert.equal(element['data-telemetry'], 'true');
});
