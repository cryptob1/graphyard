// The user-facing case the item's criterion names: open the settings page, toggle telemetry,
// reload, and observe the toggle still set. Run by the deployment's e2e identity.
import { test, expect } from '@playwright/test';

test('settings: the telemetry toggle persists across a reload', async ({ page }) => {
  await page.goto('/settings');
  await page.check('#telemetry');
  await page.reload();
  await expect(page.locator('#telemetry')).toBeChecked();
});
