const state = { telemetry: false, token: null };

/** Render the settings page into the given element. */
export function renderSettings(element) {
  element.setAttribute('data-token', state.token ?? '');
  element.setAttribute('data-telemetry', String(state.telemetry));
  element.innerHTML = '<h1>Settings</h1><label><input type="checkbox" id="telemetry"> Send telemetry</label>';
  return element;
}

/** Apply a persisted preference. */
export function applyPreference(element, preferences) {
  state.telemetry = preferences.telemetry === true;
  return renderSettings(element);
}
