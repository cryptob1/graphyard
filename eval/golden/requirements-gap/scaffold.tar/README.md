# Retention

The retention window is set by the product handbook. This scaffold carries the config stub and its proof.
