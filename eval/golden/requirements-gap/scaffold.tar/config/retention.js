// The retention window in days, set from the product handbook's decision.
export const retentionDays = null;
