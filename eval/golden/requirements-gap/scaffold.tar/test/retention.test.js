import test from 'node:test';
import assert from 'node:assert/strict';
import { retentionDays } from '../config/retention.js';

test('the retention window is a positive number of days', () => {
  assert.equal(Number.isInteger(retentionDays), true);
  assert.ok(retentionDays > 0);
});
