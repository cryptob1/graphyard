# Report

A tiny report renderer: one compact mode today, a verbose mode asked for by its callers.
