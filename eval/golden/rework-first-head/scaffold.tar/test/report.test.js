import test from 'node:test';
import assert from 'node:assert/strict';
import { format } from '../lib/report.js';

test('compact renders one row per line', () => {
  assert.equal(format(['cpu 2', 'mem 4'], { mode: 'compact' }), 'cpu 2\nmem 4');
});
