import test from 'node:test';
import assert from 'node:assert/strict';
import { total } from '../lib/cart.js';

test('total applies the discount after summing', () => {
  assert.equal(total([{ cents: 200 }, { cents: 300 }], 100), 400);
});
