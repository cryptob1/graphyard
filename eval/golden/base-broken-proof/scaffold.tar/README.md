# Cart

A tiny cart library whose total drops the discount: its proof fails on the base commit.
