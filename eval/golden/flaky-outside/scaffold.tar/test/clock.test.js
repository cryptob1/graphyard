import test from 'node:test';
import assert from 'node:assert/strict';

// Outside the item's files and flaky by timing: this fails whenever the wait crosses a minute
// boundary, about one run in fifty. The eval reads whether the pipeline blames the item for it.
test('the minute does not turn while a read is in flight', async () => {
  const before = new Date();
  await new Promise(accept => setTimeout(accept, 1200));
  const after = new Date();
  assert.equal(after.getMinutes(), before.getMinutes());
});
