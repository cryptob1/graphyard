# Greet

A tiny greeting library. Its test directory carries a timing flake outside anything the filed item touches.
