import test from 'node:test';
import assert from 'node:assert/strict';
import { parseNote } from '../lib/notes.js';

test('parseNote splits title and body', () => {
  assert.deepEqual(parseNote('Buy milk\nskim, two litres'), { title: 'Buy milk', body: 'skim, two litres' });
});
