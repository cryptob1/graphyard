import { readFileSync } from 'node:fs';

const text = readFileSync(new URL('../docs/guide.md', import.meta.url), 'utf8');
const words = text.split(/\s+/).filter(Boolean).length;
const sections = ['## Setup', '## Run', '## Troubleshoot'].filter(heading => text.includes(heading));
if (words > 400) { console.error(`docs/guide.md holds ${words} words, over the 400-word budget`); process.exit(1); }
if (sections.length !== 3) { console.error(`docs/guide.md lost sections: ${sections.join(', ') || 'none'}`); process.exit(1); }
console.log(`docs/guide.md holds ${words} words, within the 400-word budget, with every section kept`);
