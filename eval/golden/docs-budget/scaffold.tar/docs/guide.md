# Guide

This guide explains how the tiny deployment tool is set up, run and troubleshot. It has outgrown
its 400-word budget, and the docs-budget item filed against this scaffold asks for a trim that
keeps every section while the budget check stays green.

## Setup

Setup begins with installing the tool on the machine that will run it. The tool ships as a single
package, so installation is one command and the package manager resolves the few dependencies it
carries by itself. After the package is in place, create a configuration directory beside the
installation. The tool reads its configuration from that directory on every start, and it writes
its own state files there too, so the directory must be writable by the user that runs the tool.

Configuration itself is a single file with three keys. The first key names the port the tool
listens on; the second names the directory where reports are written; the third names the log
level. Every key has a sensible default, so a configuration file is only needed when the defaults
do not fit the machine. If a key is misspelled the tool refuses to start and prints the key it did
not understand, which is usually enough to find the typo in a few seconds.

## Run

Run the tool from the machine it was installed on with its start command. On start it reads the
configuration, opens the port, and begins writing a report once an hour. The report is a plain
JSON file whose name carries the hour it covers, so reports sort naturally in a directory listing
and can be archived by moving them. The tool is restart-safe: if it stops while writing a report
it starts that report again on the next start, and it never leaves a partial report behind.

While the tool runs it logs one line per request at the info level, and one line per internal
decision at the debug level. Raising the configured log level to debug is the usual first step
when a run behaves oddly. The log goes to standard error, so a run under a service manager keeps
the log in the manager's journal with no extra configuration at all.

## Troubleshoot

Troubleshoot a tool that will not start by reading the refusal first. A refusal that names the
port means another process holds it; choose a different port in the configuration. A refusal that
names a configuration key means the file carries a key the tool does not know, or a value of the
wrong shape; compare the file against the reference above. A tool that starts but writes no
reports is usually pointing at a report directory it cannot write, which the log names on the
first failed write. Nothing in the tool retries a refused write, so the directory must be fixed
before reports appear again.

When nothing else helps, delete the state files and start again: the tool keeps no history that
matters beyond the reports it has already written, and a fresh state directory resolves every
state corruption this tool has been seen to suffer.
